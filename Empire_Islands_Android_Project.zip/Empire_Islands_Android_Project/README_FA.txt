پروژه اندروید Empire Islands (نسخه آزمایشی)

این پوشه یک پروژه Android Studio است که بازی HTML را در WebView تمام‌صفحه اجرا می‌کند.

ساخت APK:
1) Android Studio را باز کنید.
2) پوشه Empire_Islands_Android_Project را Open کنید.
3) صبر کنید Gradle و Android SDK موردنیاز دریافت شوند.
4) از منوی Build گزینه Build Bundle(s) / APK(s) و سپس Build APK(s) را بزنید.
5) فایل APK آزمایشی در app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نیازمندی‌ها: Android Studio، Android SDK Platform 35 و JDK 17 یا جدیدتر.
این پروژه در محیط فعلی کامپایل نشده و APK نهایی نیست؛ برای ساخت APK باید مراحل بالا در Android Studio انجام شود.
